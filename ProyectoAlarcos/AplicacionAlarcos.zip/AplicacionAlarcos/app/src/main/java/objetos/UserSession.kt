package objetos

object UserSession {
    var email: String? = null
    var nombre: String? = null
    var id: String? = null
}