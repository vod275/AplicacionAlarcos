package com.example.aplicacionalarcos

import adaptadorNuevasComidas.NuevaComidaAdapter
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aplicacionalarcos.databinding.ActivityNuevasComidasBinding
import android.util.Log  // Importa Log de Android
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import modelosNuevasComidas.Ingrediente
import objetos.UserSession

class NuevasComidas : AppCompatActivity() {
    private lateinit var db: FirebaseFirestore
    private lateinit var firebaseStorage: FirebaseStorage
    private lateinit var binding: ActivityNuevasComidasBinding
    private lateinit var adapter: NuevaComidaAdapter
    private val listaIngredientes = mutableListOf<Ingrediente>()
    private lateinit var comidaNombre: String
    private lateinit var comidaId: String
    private lateinit var appLogo: ImageButton

    // Lanzador de la cámara
    private val takePictureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val photoUri: Uri? = result.data?.data
                photoUri?.let {
                    uploadImageToFirebase(it)
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNuevasComidasBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = FirebaseFirestore.getInstance()
        firebaseStorage = FirebaseStorage.getInstance()

        binding.RVNuevasComidas.layoutManager = LinearLayoutManager(this)

        // Inicializar el adaptador vacío
        adapter = NuevaComidaAdapter(listaIngredientes) { ingrediente ->
            Toast.makeText(this, getString(R.string.seleccionaste_ingrediente, ingrediente.nombre), Toast.LENGTH_SHORT).show()
        }
        binding.RVNuevasComidas.adapter = adapter

        obtenerIngredientes()

        // Botón para volver atrás
        binding.obAtras2.setOnClickListener {
            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
            finish()
        }

        // Botón para añadir un nuevo ingrediente
        binding.obAnadirIngredientes.setOnClickListener {
            val intent = Intent(this, ActivityIngredientes::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }

        // Botón para eliminar ingredientes seleccionados
        binding.obBorrar.setOnClickListener {
            if (::adapter.isInitialized) {
                adapter.eliminarIngredientesSeleccionados()
            }
        }

        // Botón para añadir una nueva comida con ingredientes seleccionados
        binding.obAnadirComida.setOnClickListener {
            if (::adapter.isInitialized) {
                val seleccionados = adapter.getSeleccionados()
                val nombrePlato = binding.EtNombrePlato.text.toString()

                if (seleccionados.isNotEmpty() && nombrePlato.isNotBlank()) {
                    val intent = Intent(this, ActivityCantidadIngredientes::class.java).apply {
                        putExtra("ingredientesSeleccionados", ArrayList(seleccionados))
                        putExtra("nombrePlato", nombrePlato)
                    }
                    startActivity(intent)
                } else {
                    val mensaje = if (seleccionados.isEmpty()) getString(R.string.no_has_seleccionado_ning_n_ingrediente)
                    else getString(R.string.debes_escribir_un_nombre_para_el_plato)
                    Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
                }
            } else {
                Log.e("Adapter", getString(R.string.el_adaptador_no_ha_sido_inicializado_a_n))
            }
        }

        // Acción del ImageButton para tomar una foto
        appLogo = findViewById(R.id.appLogo)
        appLogo.setOnClickListener {
            openCamera()
        }
    }

    // Abrir la cámara
    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        takePictureLauncher.launch(intent)
    }

    // Subir la foto a Firebase Storage
    private fun uploadImageToFirebase(imageUri: Uri) {
        // Creamos una referencia a Firebase Storage usando el ID de la comida
        val storageReference = firebaseStorage.reference.child("images/$comidaId.jpg")

        // Subimos la foto
        storageReference.putFile(imageUri)
            .addOnSuccessListener {
                Toast.makeText(this,
                    getString(R.string.foto_subida_exitosamente), Toast.LENGTH_SHORT).show()
                // Aquí puedes guardar la URL de la imagen en Firestore si lo deseas
                storageReference.downloadUrl.addOnSuccessListener { uri ->
                    saveImageUrlToFirestore(uri.toString())
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, getString(R.string.error_al_subir_la_foto), Toast.LENGTH_SHORT).show()
            }
    }

    // Guardar la URL de la imagen en Firestore
    private fun saveImageUrlToFirestore(imageUrl: String) {
        db.collection("comidas")
            .document(comidaId)
            .update("imageUrl", imageUrl)
            .addOnSuccessListener {
                Toast.makeText(this,
                    getString(R.string.url_de_la_imagen_guardada_correctamente), Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, getString(R.string.error_al_guardar_url), Toast.LENGTH_SHORT).show()
            }
    }

    private fun obtenerIngredientes() {
        val userId = UserSession.id

        db.collection("ingredientes")
            .whereEqualTo("userId", userId) // Filtramos por el usuario actual
            .get()
            .addOnSuccessListener { result ->
                listaIngredientes.clear()

                for (document in result) {
                    val ingrediente = Ingrediente(
                        id = document.id,
                        nombre = document.getString("nombre") ?: getString(R.string.sin_nombre),
                        carbohidratosPor100g = document.getDouble("carbohidratos") ?: 0.0,
                        grasasPor100g = document.getDouble("grasas") ?: 0.0,
                        proteinasPor100g = document.getDouble("proteinas") ?: 0.0,
                        salPor100g = document.getDouble("sal") ?: 0.0,
                        valorEnergeticoPor100g = document.getDouble("valorEnergetico") ?: 0.0
                    )
                    listaIngredientes.add(ingrediente)
                }

                adapter.notifyDataSetChanged() // Refrescar RecyclerView
            }
            .addOnFailureListener { exception ->
                Log.e("Firestore", getString(R.string.error_al_obtener_ingredientes), exception)
            }

    }
}
