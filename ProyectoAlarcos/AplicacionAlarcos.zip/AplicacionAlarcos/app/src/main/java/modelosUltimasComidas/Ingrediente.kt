package modelosUltimasComidas

data class Ingrediente(val nombre: String, val cantidad: String) {

}
